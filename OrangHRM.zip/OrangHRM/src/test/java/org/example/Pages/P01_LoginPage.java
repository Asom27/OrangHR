package org.example.Pages;

import org.example.StepDefinition.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P01_LoginPage {

    public WebElement login_link(){
        By login=By.className("ico-login");
        return Hooks.driver.findElement(login);
    }
    public WebElement Username()
    {
        By username = By.name("Username");
        WebElement Username = Hooks.driver.findElement(username);
        return Username;
    }

    public WebElement Password()
    {
        By password = By.id("Password");
        WebElement Password = Hooks.driver.findElement(password);
        return Password;

    }
    public  WebElement LoginBtn()
    {
        By login = By.cssSelector("button[class=\"button-1 login-button\"]");
        WebElement LogIn = Hooks.driver.findElement(login);
        return LogIn;
    }
    public void loginStep(String user,String pass){
       Username().clear();
        Username().sendKeys(user);
        Password().sendKeys(pass);
    }

    public WebElement errormessage(){
        By msg=By.cssSelector("div[class=\"message-error validation-summary-errors\"]");
        WebElement error= Hooks.driver.findElement(msg);
        return error;
    }

}
