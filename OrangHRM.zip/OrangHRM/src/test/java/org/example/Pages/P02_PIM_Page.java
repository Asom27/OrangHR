package org.example.Pages;

import org.example.StepDefinition.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P02_PIM_Page {

    public WebElement search(){
        By search=By.className("ico-search");
        WebElement ser= Hooks.driver.findElement(search);
        return ser;
    }
    public WebElement Status(){
        WebElement Status=Hooks.driver.findElement(By.name("Employment Status"));
        return Status;
    }
    public WebElement JTitle(){

        WebElement JTitle=Hooks.driver.findElement(By.name("Job Title"));
        return JTitle;
    }
    public WebElement SUnit(){
        WebElement SUnit=Hooks.driver.findElement(By.name("Sub Unit"));
        return SUnit;
    }
    public WebElement Status(String type){
        WebElement Status=null;
        if(type.equals("Freelace")){
            Status=Hooks.driver.findElement(By.cssSelector("input[type=\"radio\"][id=\"Freelance\"]"));
        }
        else if(type.equals("Full-Time Contract")){
            Status=Hooks.driver.findElement(By.cssSelector("input[type=\"radio\"][id=\"Full-Time Contract\"]"));
        }
        return Status;
    }

    public WebElement employee_name(){
        By employeename=By.cssSelector("input[id^=\"EmployeeName\"]");
        WebElement Ename=Hooks.driver.findElement(employeename);
        return Ename;
    }

    public WebElement EId(){
        By EId=By.cssSelector("input[id^=\"Employee Id\"]");
        WebElement Id=Hooks.driver.findElement(EId);
        return Id;
    }

    public WebElement email(){
        By email=By.cssSelector("input[id^=\"Email\"]");
        WebElement em=Hooks.driver.findElement(email);
        return em;
    }

    public WebElement Supervisor_Name(){
        By Supervisor_Name=By.cssSelector("input[id^=\"Supervisor_Name\"]");
        WebElement SName=Hooks.driver.findElement(Supervisor_Name);
        return SName;
    
    }

    public WebElement searchBtn(){
        By ser = By.cssSelector("button[type=\"submit\"][id=\"search-button\"]");
        WebElement serBtn = Hooks.driver.findElement(ser);
        return serBtn;
    }



}
