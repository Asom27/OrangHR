package org.example.StepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages.P02_PIM_Page;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D02_PIMDef {

    P02_PIM_Page search=new P02_PIM_Page();

    @And("user navigate to home page")
    public void user_navigate_to_home_page()
    {
        String url = "https://demo.nopcommerce.com/";
        Hooks.driver.navigate() .to(url);
    }

    @And("user click search")
    public void user_click_search(){
        search.search().click();
    }
    @When("^user fills Ename\"(.*)\" EId\"(.*)\" Status\"(.*)\"SName\"(.*)\" JTitle\"(.*)\" SUnit\"(.*)\" valid data$")

    public void user_fills_personal_valid_data(String Ename,String EId,String Status,String SName,String JTitle, String SUnit) throws InterruptedException {
        Thread.sleep(1000);
        search.search().click();
     search.employee_name().sendKeys(Ename);
       search.EId().sendKeys(EId);
        search.Supervisor_Name().sendKeys(SName);
        Thread.sleep(1000);

        Select selectedStatus =new Select(search.Status());
        selectedStatus.selectByVisibleText( Status);
        Select selectedJTitle =new Select(search.JTitle());
        selectedJTitle.selectByValue(JTitle);
        Select selectedSUnit =new Select(search.SUnit());
        selectedSUnit.selectByValue(SUnit);

    }

    @And("user clicks search button")
    public void user_clicks_search_button() throws InterruptedException {
       search.search().click();
        Thread.sleep(3000);
    }

    @Then("success message is displayed")
    public void success_message_is_displayed(){
        Assert.assertTrue(Hooks.driver.findElement(By.cssSelector("div[class=\"result\"]")).isDisplayed());
        SoftAssert soft = new SoftAssert();
        soft.assertTrue(Hooks.driver.findElement(By.cssSelector("div[class=\"result\"]")).isDisplayed());
        soft.assertTrue(Hooks.driver.getCurrentUrl().contains("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList/"));
        soft.assertTrue(Hooks.driver.findElement(By.cssSelector("a[href=\"/user/info\"][class=\"ico-account\"]")).isDisplayed());
        soft.assertAll();
    }


}
